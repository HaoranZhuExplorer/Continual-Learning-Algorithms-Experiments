#!/usr/bin/env bash
docker build -t cvpr_clvision_image .
